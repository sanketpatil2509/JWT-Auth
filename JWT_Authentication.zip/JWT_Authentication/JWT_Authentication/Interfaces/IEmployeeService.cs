﻿using JWT_Authentication.Models;

namespace JWT_Authentication.Interfaces
{
    public interface IEmployeeService
    {
        public List<Employee> GetEmployeeDetail();

        public Employee AddEmployee(Employee employee);
    }
}
